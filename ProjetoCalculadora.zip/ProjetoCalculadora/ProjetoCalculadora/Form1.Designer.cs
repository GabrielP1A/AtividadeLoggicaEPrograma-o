﻿namespace ProjetoCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.btnponto = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.btn2pt = new System.Windows.Forms.Button();
            this.btnac = new System.Windows.Forms.Button();
            this.btnporc = new System.Windows.Forms.Button();
            this.btnpard = new System.Windows.Forms.Button();
            this.btnpare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn7.Location = new System.Drawing.Point(194, 95);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(56, 36);
            this.btn7.TabIndex = 0;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn8.Location = new System.Drawing.Point(256, 95);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(55, 36);
            this.btn8.TabIndex = 1;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn9.Location = new System.Drawing.Point(317, 95);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(55, 36);
            this.btn9.TabIndex = 2;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button4.Location = new System.Drawing.Point(194, 137);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(56, 36);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(256, 137);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(55, 36);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Location = new System.Drawing.Point(317, 137);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(55, 36);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(194, 179);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(56, 36);
            this.button1.TabIndex = 6;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button2.Location = new System.Drawing.Point(256, 179);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 36);
            this.button2.TabIndex = 7;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(317, 179);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(55, 36);
            this.button3.TabIndex = 8;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button0.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button0.Location = new System.Drawing.Point(194, 221);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(56, 36);
            this.button0.TabIndex = 9;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // btnponto
            // 
            this.btnponto.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnponto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnponto.Location = new System.Drawing.Point(256, 221);
            this.btnponto.Name = "btnponto";
            this.btnponto.Size = new System.Drawing.Size(54, 36);
            this.btnponto.TabIndex = 10;
            this.btnponto.Text = ".";
            this.btnponto.UseVisualStyleBackColor = false;
            this.btnponto.Click += new System.EventHandler(this.btnponto_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnadd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnadd.Location = new System.Drawing.Point(378, 221);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(57, 36);
            this.btnadd.TabIndex = 11;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnigual
            // 
            this.btnigual.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnigual.Location = new System.Drawing.Point(316, 221);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(56, 36);
            this.btnigual.TabIndex = 12;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = false;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnmenos.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnmenos.Location = new System.Drawing.Point(378, 179);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(57, 36);
            this.btnmenos.TabIndex = 13;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = false;
            this.btnmenos.Click += new System.EventHandler(this.btnmenos_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button15.Location = new System.Drawing.Point(378, 137);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(57, 36);
            this.button15.TabIndex = 14;
            this.button15.Text = "x";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // btn2pt
            // 
            this.btn2pt.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn2pt.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn2pt.Location = new System.Drawing.Point(378, 95);
            this.btn2pt.Name = "btn2pt";
            this.btn2pt.Size = new System.Drawing.Size(57, 36);
            this.btn2pt.TabIndex = 15;
            this.btn2pt.Text = ":";
            this.btn2pt.UseVisualStyleBackColor = false;
            this.btn2pt.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnac
            // 
            this.btnac.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnac.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnac.Location = new System.Drawing.Point(378, 53);
            this.btnac.Name = "btnac";
            this.btnac.Size = new System.Drawing.Size(57, 36);
            this.btnac.TabIndex = 16;
            this.btnac.Text = "AC";
            this.btnac.UseVisualStyleBackColor = false;
            this.btnac.Click += new System.EventHandler(this.btnac_Click);
            // 
            // btnporc
            // 
            this.btnporc.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnporc.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnporc.Location = new System.Drawing.Point(315, 53);
            this.btnporc.Name = "btnporc";
            this.btnporc.Size = new System.Drawing.Size(57, 36);
            this.btnporc.TabIndex = 17;
            this.btnporc.Text = "%";
            this.btnporc.UseVisualStyleBackColor = false;
            this.btnporc.Click += new System.EventHandler(this.btnporc_Click);
            // 
            // btnpard
            // 
            this.btnpard.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnpard.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnpard.Location = new System.Drawing.Point(256, 53);
            this.btnpard.Name = "btnpard";
            this.btnpard.Size = new System.Drawing.Size(57, 36);
            this.btnpard.TabIndex = 18;
            this.btnpard.Text = ")";
            this.btnpard.UseVisualStyleBackColor = false;
            this.btnpard.Click += new System.EventHandler(this.btnpard_Click);
            // 
            // btnpare
            // 
            this.btnpare.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnpare.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnpare.Location = new System.Drawing.Point(193, 53);
            this.btnpare.Name = "btnpare";
            this.btnpare.Size = new System.Drawing.Size(57, 36);
            this.btnpare.TabIndex = 19;
            this.btnpare.Text = "(";
            this.btnpare.UseVisualStyleBackColor = false;
            this.btnpare.Click += new System.EventHandler(this.btnpare_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnpare);
            this.Controls.Add(this.btnpard);
            this.Controls.Add(this.btnporc);
            this.Controls.Add(this.btnac);
            this.Controls.Add(this.btn2pt);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnponto);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button btnponto;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button btn2pt;
        private System.Windows.Forms.Button btnac;
        private System.Windows.Forms.Button btnporc;
        private System.Windows.Forms.Button btnpard;
        private System.Windows.Forms.Button btnpare;
    }
}

