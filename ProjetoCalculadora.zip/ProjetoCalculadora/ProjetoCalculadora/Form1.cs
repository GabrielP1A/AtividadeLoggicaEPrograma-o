﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btn2pt." + btn2pt.Text);
        }

        private void button18_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnpare_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void btnpard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpard." + btnpard.Text);
        }

        private void btnporc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnporc." + btnporc.Text);
        }

        private void btnac_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnac." + btnac.Text);
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btn7." + btn7.Text);
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btn8." + btn8.Text);
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btn9." + btn9.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void btnmenos_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void button0_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void btnponto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void btnigual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no btnpare." + btnpare.Text);
        }
    }
}
